# Chess Clock Application

## Overview

This is a modern chess clock application built with React, TypeScript, and Express. The application features a responsive design using Tailwind CSS and shadcn/ui components. Currently, it implements a fully-functional chess clock interface with time controls and game management features.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Full-Stack Architecture
The application follows a monolithic full-stack architecture with:
- **Frontend**: React with TypeScript and Vite for bundling
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (configured but not actively used in current implementation)
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Development**: Hot module replacement and development tooling via Vite

### Build System
- **Development**: `tsx` for TypeScript execution and Vite dev server
- **Production**: ESBuild for server bundling and Vite for client bundling
- **Database**: Drizzle Kit for schema management and migrations

## Key Components

### Frontend Components
- **Chess Clock Page**: Main application interface with dual-player timers, game controls, and settings
- **UI Components**: Comprehensive shadcn/ui component library including buttons, cards, selects, dialogs, and form controls
- **Routing**: Wouter for client-side routing with fallback to 404 page
- **State Management**: React hooks for local state, TanStack Query for server state (ready for future API integration)

### Backend Infrastructure
- **Express Server**: RESTful API server with JSON middleware and request logging
- **Storage Layer**: Abstracted storage interface with in-memory implementation (ready for database integration)
- **Route Registration**: Modular route system with `/api` prefix convention
- **Development Features**: Hot reload, error handling, and request/response logging

### Database Schema
- **Users Table**: Basic user entity with username/password fields
- **Drizzle Integration**: Type-safe database operations with Zod validation
- **Migration System**: Automated database schema versioning

## Data Flow

### Current Implementation
1. **Client-Side State**: Chess clock state managed entirely in React components
2. **Local Storage**: No persistence currently implemented
3. **API Ready**: Infrastructure prepared for future server-side features

### Future API Integration
1. **Authentication**: User registration/login endpoints ready for implementation
2. **Game Persistence**: Save/load game states via RESTful API
3. **Real-time Features**: WebSocket integration possible for multiplayer games

## External Dependencies

### Core Framework Dependencies
- **React 18**: Modern React with hooks and concurrent features
- **Express**: Minimal web framework for Node.js
- **TypeScript**: Type safety across entire application

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework with custom theme
- **Radix UI**: Accessible primitive components via shadcn/ui
- **Lucide Icons**: Consistent icon system
- **Class Variance Authority**: Type-safe component variants

### Database and ORM
- **Drizzle ORM**: Type-safe database operations
- **Neon Database**: PostgreSQL serverless database provider
- **Zod**: Runtime type validation and schema definition

### Development Tools
- **Vite**: Fast build tool with HMR
- **ESBuild**: Fast JavaScript bundler for production
- **Replit Integration**: Development environment optimizations

## Deployment Strategy

### Development Environment
- **Local Development**: `npm run dev` starts both client and server with hot reload
- **Type Checking**: `npm run check` for TypeScript validation
- **Database**: `npm run db:push` for schema synchronization

### Production Build
1. **Client Build**: Vite bundles React app to `dist/public`
2. **Server Build**: ESBuild bundles Express server to `dist/index.js`
3. **Static Serving**: Express serves client build in production
4. **Environment**: NODE_ENV-based configuration switching

### Database Deployment
- **Schema Management**: Drizzle migrations in `./migrations` directory
- **Connection**: Environment variable-based database URL configuration
- **Provider**: Neon Database for serverless PostgreSQL hosting

The architecture is designed for easy scaling from the current client-side chess clock to a full-featured multiplayer chess platform with user accounts, game persistence, and real-time gameplay.