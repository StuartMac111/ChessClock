import React, { useState, useEffect, useRef, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Clock, Settings, Play, Pause, RotateCcw, User, AlertTriangle } from "lucide-react";

interface PlayerState {
  timeRemaining: number;
  movesCount: number;
}

interface GameState {
  player1: PlayerState;
  player2: PlayerState;
  isRunning: boolean;
  currentPlayer: 1 | 2;
  gameStartTime: number | null;
  totalGameDuration: number;
}

const TIME_OPTIONS = [
  { value: 60, label: "1 minute" },
  { value: 180, label: "3 minutes" },
  { value: 300, label: "5 minutes" },
  { value: 600, label: "10 minutes" },
  { value: 900, label: "15 minutes" },
  { value: 1800, label: "30 minutes" },
  { value: 0, label: "Custom" },
];

const INCREMENT_OPTIONS = [
  { value: 0, label: "None" },
  { value: 3, label: "3 seconds" },
  { value: 5, label: "5 seconds" },
  { value: 10, label: "10 seconds" },
];

const PENALTY_OPTIONS = [
  { value: 10, label: "10 seconds" },
  { value: 30, label: "30 seconds" },
  { value: 60, label: "1 minute" },
  { value: 120, label: "2 minutes" },
  { value: 300, label: "5 minutes" },
  { value: 0, label: "Custom" },
];

export default function ChessClock() {
  const [gameState, setGameState] = useState<GameState>({
    player1: { timeRemaining: 600, movesCount: 0 },
    player2: { timeRemaining: 600, movesCount: 0 },
    isRunning: false,
    currentPlayer: 1,
    gameStartTime: null,
    totalGameDuration: 0,
  });

  const [timePlayer1, setTimePlayer1] = useState(600);
  const [timePlayer2, setTimePlayer2] = useState(600);
  const [customTimePlayer1, setCustomTimePlayer1] = useState(10);
  const [customTimePlayer2, setCustomTimePlayer2] = useState(10);
  const [increment, setIncrement] = useState(0);
  const [penaltyTime, setPenaltyTime] = useState(30);
  const [customPenalty, setCustomPenalty] = useState(30);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Format time display
  const formatTime = useCallback((seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  }, []);

  // Format game duration
  const formatGameDuration = useCallback((seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    
    if (hours > 0) {
      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  }, []);

  // Play timer alert sound
  const playTimerAlert = useCallback(() => {
    try {
      // Create a simple beep sound using Web Audio API
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      oscillator.type = 'sine';
      
      gainNode.gain.setValueAtTime(0, audioContext.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.1);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 1);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 1);
    } catch (error) {
      console.log('Audio notification not available');
    }
  }, []);

  // Timer tick function
  const tick = useCallback(() => {
    setGameState(prevState => {
      if (!prevState.isRunning) return prevState;

      const currentPlayerKey = prevState.currentPlayer === 1 ? 'player1' : 'player2';
      const currentPlayer = prevState[currentPlayerKey];
      
      if (currentPlayer.timeRemaining <= 0) {
        // Time expired
        playTimerAlert();
        return {
          ...prevState,
          isRunning: false,
        };
      }

      const newTimeRemaining = currentPlayer.timeRemaining - 1;
      const newTotalDuration = prevState.totalGameDuration + 1;

      return {
        ...prevState,
        [currentPlayerKey]: {
          ...currentPlayer,
          timeRemaining: newTimeRemaining,
        },
        totalGameDuration: newTotalDuration,
      };
    });
  }, [playTimerAlert]);

  // Timer effect
  useEffect(() => {
    if (gameState.isRunning) {
      intervalRef.current = setInterval(tick, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [gameState.isRunning, tick]);

  // Keyboard controls effect
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      // Space bar to start game or switch players
      if (event.code === 'Space') {
        event.preventDefault();
        if (!gameState.isRunning && gameState.totalGameDuration === 0) {
          // If game hasn't started, start with Player 1
          startGameWithPlayer(1);
        } else if (gameState.isRunning) {
          // If game is running, switch to the other player
          const nextPlayer = gameState.currentPlayer === 1 ? 2 : 1;
          switchToPlayer(nextPlayer);
        } else {
          // If game is paused, resume it
          toggleGameState();
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, [gameState.isRunning, gameState.totalGameDuration, gameState.currentPlayer]);

  // Apply settings
  const applySettings = () => {
    const actualTimePlayer1 = timePlayer1 === 0 ? customTimePlayer1 * 60 : timePlayer1;
    const actualTimePlayer2 = timePlayer2 === 0 ? customTimePlayer2 * 60 : timePlayer2;
    
    setGameState(prevState => ({
      ...prevState,
      player1: { timeRemaining: actualTimePlayer1, movesCount: 0 },
      player2: { timeRemaining: actualTimePlayer2, movesCount: 0 },
      isRunning: false,
      currentPlayer: 1,
      gameStartTime: null,
      totalGameDuration: 0,
    }));
  };

  // Toggle game state (start/pause)
  const toggleGameState = () => {
    setGameState(prevState => {
      const newIsRunning = !prevState.isRunning;
      const newGameStartTime = newIsRunning && !prevState.gameStartTime 
        ? Date.now() 
        : prevState.gameStartTime;

      return {
        ...prevState,
        isRunning: newIsRunning,
        gameStartTime: newGameStartTime,
      };
    });
  };

  // Reset game
  const resetGame = () => {
    const actualTimePlayer1 = timePlayer1 === 0 ? customTimePlayer1 * 60 : timePlayer1;
    const actualTimePlayer2 = timePlayer2 === 0 ? customTimePlayer2 * 60 : timePlayer2;
    
    setGameState({
      player1: { timeRemaining: actualTimePlayer1, movesCount: 0 },
      player2: { timeRemaining: actualTimePlayer2, movesCount: 0 },
      isRunning: false,
      currentPlayer: 1,
      gameStartTime: null,
      totalGameDuration: 0,
    });
  };

  // Apply penalty to a player (subtract time for illegal move)
  const applyPenalty = (player: 1 | 2) => {
    const actualPenalty = penaltyTime === 0 ? customPenalty : penaltyTime;
    setGameState(prevState => {
      const playerKey = player === 1 ? 'player1' : 'player2';
      const currentPlayer = prevState[playerKey];
      
      return {
        ...prevState,
        [playerKey]: {
          ...currentPlayer,
          timeRemaining: Math.max(0, currentPlayer.timeRemaining - actualPenalty),
        }
      };
    });
  };

  // Switch to player
  const switchToPlayer = (player: 1 | 2) => {
    if (!gameState.isRunning) return;
    
    setGameState(prevState => {
      const otherPlayer = player === 1 ? 2 : 1;
      const otherPlayerKey = otherPlayer === 1 ? 'player1' : 'player2';
      
      // Add increment to the player who just finished their turn
      const updatedOtherPlayer = {
        ...prevState[otherPlayerKey],
        timeRemaining: prevState[otherPlayerKey].timeRemaining + increment,
        movesCount: prevState[otherPlayerKey].movesCount + 1,
      };

      return {
        ...prevState,
        currentPlayer: player,
        [otherPlayerKey]: updatedOtherPlayer,
      };
    });
  };

  // Start game with specific player
  const startGameWithPlayer = (player: 1 | 2) => {
    setGameState(prevState => ({
      ...prevState,
      isRunning: true,
      currentPlayer: player,
      gameStartTime: Date.now(),
    }));
  };

  // Get the actual penalty amount to display
  const getDisplayPenalty = () => {
    return penaltyTime === 0 ? customPenalty : penaltyTime;
  };

  // Handle timer tap (for mobile/touch devices)
  const handleTimerTap = (player: 1 | 2) => {
    if (!gameState.isRunning && gameState.totalGameDuration === 0) {
      // If game hasn't started, start with the tapped player
      startGameWithPlayer(player);
    } else if (gameState.isRunning && gameState.currentPlayer !== player) {
      // If game is running and it's not this player's turn, switch to them
      switchToPlayer(player);
    }
  };

  // Get game status
  const getGameStatus = () => {
    if (!gameState.isRunning && gameState.totalGameDuration === 0) {
      return "Ready";
    } else if (gameState.isRunning) {
      return "Running";
    } else if (gameState.player1.timeRemaining <= 0) {
      return "Player 2 Wins";
    } else if (gameState.player2.timeRemaining <= 0) {
      return "Player 1 Wins";
    } else {
      return "Paused";
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Clock className="text-chess-blue text-2xl" />
            <h1 className="text-2xl font-bold text-gray-900">Chess Clock Pro</h1>
          </div>
          <div className="flex items-center space-x-2">
            <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-medium">
              {getGameStatus()}
            </span>
          </div>
        </div>
      </header>

      {/* Main Game Area */}
      <main className="flex-1 flex flex-col max-w-4xl mx-auto w-full p-4 space-y-6">
        
        {/* Time Settings Panel */}
        <Card className="p-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
            <Settings className="text-chess-blue mr-2" />
            Game Settings
          </h2>
          <div className="space-y-4">
            {/* Main Settings Row */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Player 1 Time
                </label>
                <Select value={timePlayer1.toString()} onValueChange={(value) => setTimePlayer1(parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select time" />
                  </SelectTrigger>
                  <SelectContent>
                    {TIME_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value.toString()}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Player 2 Time
                </label>
                <Select value={timePlayer2.toString()} onValueChange={(value) => setTimePlayer2(parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select time" />
                  </SelectTrigger>
                  <SelectContent>
                    {TIME_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value.toString()}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Increment
                </label>
                <Select value={increment.toString()} onValueChange={(value) => setIncrement(parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select increment" />
                  </SelectTrigger>
                  <SelectContent>
                    {INCREMENT_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value.toString()}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Penalty Time
                </label>
                <Select value={penaltyTime.toString()} onValueChange={(value) => setPenaltyTime(parseInt(value))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select penalty" />
                  </SelectTrigger>
                  <SelectContent>
                    {PENALTY_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value.toString()}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Custom Time Inputs Row */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {timePlayer1 === 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Custom P1 Time (minutes)
                  </label>
                  <Input
                    type="number"
                    value={customTimePlayer1}
                    onChange={(e) => setCustomTimePlayer1(parseFloat(e.target.value) || 0)}
                    placeholder="Enter minutes"
                    min="0.1"
                    max="120"
                    step="0.1"
                  />
                </div>
              )}
              {timePlayer2 === 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Custom P2 Time (minutes)
                  </label>
                  <Input
                    type="number"
                    value={customTimePlayer2}
                    onChange={(e) => setCustomTimePlayer2(parseFloat(e.target.value) || 0)}
                    placeholder="Enter minutes"
                    min="0.1"
                    max="120"
                    step="0.1"
                  />
                </div>
              )}
              <div></div>
              {penaltyTime === 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Custom Penalty (seconds)
                  </label>
                  <Input
                    type="number"
                    value={customPenalty}
                    onChange={(e) => setCustomPenalty(parseInt(e.target.value) || 0)}
                    placeholder="Enter seconds"
                    min="1"
                    max="3600"
                  />
                </div>
              )}
            </div>

            {/* Apply Button */}
            <div className="flex justify-center">
              <Button 
                onClick={applySettings}
                className="bg-chess-blue hover:bg-blue-700 px-8 py-2"
                disabled={gameState.isRunning}
              >
                <Settings className="mr-2 h-4 w-4" />
                Apply Settings
              </Button>
            </div>
          </div>
        </Card>

        {/* Chess Timers */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1">
          
          {/* Player 1 Timer */}
          <Card className={`rounded-xl shadow-lg border-4 transition-all duration-300 hover:shadow-xl ${
            gameState.currentPlayer === 1 && gameState.isRunning
              ? 'border-chess-green shadow-green-200' 
              : 'border-gray-200'
          }`}>
            {/* Player Header */}
            <div className="px-6 py-4 border-b border-gray-200 bg-gray-50 rounded-t-xl">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900 flex items-center">
                  <User className="text-chess-blue mr-3 text-2xl" />
                  Player 1
                </h3>
                <div className={`w-4 h-4 rounded-full transition-colors duration-300 ${
                  gameState.currentPlayer === 1 && gameState.isRunning
                    ? 'bg-chess-green'
                    : 'bg-gray-300'
                }`} />
              </div>
            </div>
            
            {/* Timer Display */}
            <div 
              className="p-8 text-center cursor-pointer transition-all duration-200 hover:bg-gray-50 active:bg-gray-100 select-none"
              onClick={() => handleTimerTap(1)}
              onTouchStart={() => handleTimerTap(1)}
            >
              <div className={`text-6xl md:text-7xl font-mono font-bold mb-4 tabular-nums ${
                gameState.player1.timeRemaining <= 60 ? 'text-chess-red' : 'text-gray-900'
              }`}>
                {formatTime(gameState.player1.timeRemaining)}
              </div>
              <div className="text-lg text-gray-600">
                {gameState.player1.movesCount} moves
              </div>
              {!gameState.isRunning && gameState.totalGameDuration === 0 && (
                <div className="text-sm text-gray-500 mt-2">
                  Tap to start
                </div>
              )}
            </div>
            
            {/* Player Action Buttons */}
            <div className="px-6 pb-6 space-y-3">
              <Button 
                onClick={() => switchToPlayer(1)}
                variant="outline"
                className="w-full py-4 text-xl font-semibold"
                disabled={!gameState.isRunning || gameState.currentPlayer === 1}
              >
                Tap to Switch
              </Button>
              <Button 
                onClick={() => applyPenalty(1)}
                variant="destructive"
                size="sm"
                className="w-full bg-chess-red hover:bg-red-600"
                disabled={!gameState.isRunning}
              >
                <AlertTriangle className="mr-2 h-4 w-4" />
                Apply Penalty (-{getDisplayPenalty()}s)
              </Button>
            </div>
          </Card>

          {/* Player 2 Timer */}
          <Card className={`rounded-xl shadow-lg border-4 transition-all duration-300 hover:shadow-xl ${
            gameState.currentPlayer === 2 && gameState.isRunning
              ? 'border-chess-green shadow-green-200' 
              : 'border-gray-200'
          }`}>
            {/* Player Header */}
            <div className="px-6 py-4 border-b border-gray-200 bg-gray-50 rounded-t-xl">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900 flex items-center">
                  <User className="text-chess-blue mr-3 text-2xl" />
                  Player 2
                </h3>
                <div className={`w-4 h-4 rounded-full transition-colors duration-300 ${
                  gameState.currentPlayer === 2 && gameState.isRunning
                    ? 'bg-chess-green'
                    : 'bg-gray-300'
                }`} />
              </div>
            </div>
            
            {/* Timer Display */}
            <div 
              className="p-8 text-center cursor-pointer transition-all duration-200 hover:bg-gray-50 active:bg-gray-100 select-none"
              onClick={() => handleTimerTap(2)}
              onTouchStart={() => handleTimerTap(2)}
            >
              <div className={`text-6xl md:text-7xl font-mono font-bold mb-4 tabular-nums ${
                gameState.player2.timeRemaining <= 60 ? 'text-chess-red' : 'text-gray-900'
              }`}>
                {formatTime(gameState.player2.timeRemaining)}
              </div>
              <div className="text-lg text-gray-600">
                {gameState.player2.movesCount} moves
              </div>
              {!gameState.isRunning && gameState.totalGameDuration === 0 && (
                <div className="text-sm text-gray-500 mt-2">
                  Tap to start
                </div>
              )}
            </div>
            
            {/* Player Action Buttons */}
            <div className="px-6 pb-6 space-y-3">
              <Button 
                onClick={() => switchToPlayer(2)}
                variant="outline"
                className="w-full py-4 text-xl font-semibold"
                disabled={!gameState.isRunning || gameState.currentPlayer === 2}
              >
                Tap to Switch
              </Button>
              <Button 
                onClick={() => applyPenalty(2)}
                variant="destructive"
                size="sm"
                className="w-full bg-chess-red hover:bg-red-600"
                disabled={!gameState.isRunning}
              >
                <AlertTriangle className="mr-2 h-4 w-4" />
                Apply Penalty (-{getDisplayPenalty()}s)
              </Button>
            </div>
          </Card>
        </div>

        {/* Control Panel */}
        <Card className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            
            {/* Start Player 1 Button */}
            <Button
              onClick={() => startGameWithPlayer(1)}
              className="bg-chess-blue hover:bg-blue-700 py-4 text-lg font-semibold"
              disabled={gameState.isRunning}
            >
              <Play className="mr-2 h-5 w-5" />
              Start P1
            </Button>

            {/* Start Player 2 Button */}
            <Button
              onClick={() => startGameWithPlayer(2)}
              className="bg-chess-blue hover:bg-blue-700 py-4 text-lg font-semibold"
              disabled={gameState.isRunning}
            >
              <Play className="mr-2 h-5 w-5" />
              Start P2
            </Button>
            
            {/* Pause Button */}
            <Button
              onClick={toggleGameState}
              className={`py-4 text-lg font-semibold ${
                gameState.isRunning 
                  ? 'bg-chess-orange hover:bg-orange-600' 
                  : 'bg-chess-green hover:bg-green-600'
              }`}
            >
              {gameState.isRunning ? (
                <>
                  <Pause className="mr-2 h-5 w-5" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="mr-2 h-5 w-5" />
                  Resume
                </>
              )}
            </Button>

            {/* Reset Button */}
            <Button
              onClick={resetGame}
              className="bg-chess-orange hover:bg-orange-600 py-4 text-lg font-semibold"
            >
              <RotateCcw className="mr-2 h-5 w-5" />
              Reset
            </Button>

            {/* Settings Button */}
            <Button
              variant="outline"
              className="bg-chess-dark hover:bg-gray-600 text-white py-4 text-lg font-semibold border-chess-dark"
              onClick={() => document.querySelector('[data-settings]')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <Settings className="mr-2 h-5 w-5" />
              Settings
            </Button>
          </div>

          {/* Game Status */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
              <div className="flex items-center space-x-4">
                <span>Current Turn:</span>
                <span className="font-semibold text-chess-blue">
                  Player {gameState.currentPlayer}
                </span>
              </div>
              <div className="flex items-center space-x-4">
                <span>Game Duration:</span>
                <span className="font-mono font-semibold">
                  {formatGameDuration(gameState.totalGameDuration)}
                </span>
              </div>
            </div>
            <div className="text-xs text-gray-500 text-center">
              💡 Press <kbd className="px-1 py-0.5 bg-gray-100 rounded text-xs">SPACE</kbd> to start game & switch players • Tap timers to start/switch on mobile
            </div>
          </div>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 px-4 py-3">
        <div className="max-w-4xl mx-auto text-center text-sm text-gray-500">
          <p>&copy; 2024 Chess Clock Pro. Professional tournament timing.</p>
        </div>
      </footer>
    </div>
  );
}
